var dato1;
let dato2;
const dato3=true;
let dato4;
let dato5;
let dato6;

dato1="cadena de texto";

dato2=20;

//dato3=true;

dato4=new Date();
dato4.getMonth();
dato4.getDate();


dato5=["uno",2,"tres"];

dato5[0];
dato5[1];
dato5[2];

dato6={
	nombre:"dato nombre",
	apellido:"dato apellido"
}

dato6.nombre;
dato6.apellido;



function nombre_de_la_funcion(valor1,valor2,valor3)
{
	// codigo de la funcion
	var suma=valor1+valor2+valor3;
}




nombre_de_la_funcion(12,12);














var tipo_cambio=3.35;


	function calculo1(){
		 var nombre;
		 let apellido;		
	}

	function calculo2(){

		var nombre;
		nombre=10;
		let apellido;
		console.log(tipo_cambio);

	}

	function calculo3(){
		let apellido;
		console.log(nombre);
		var tipo_cambio=10;
		var nombre="JC";
		let nombre="DIEGO";
		console.log(nombre); // 
	}


	
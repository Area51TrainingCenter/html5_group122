$(document).ready(function(){

	$("#boton").click(function(){
		console.log("click")
	})
	
})
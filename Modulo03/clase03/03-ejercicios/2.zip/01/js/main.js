var home=document.getElementById('home');

home.addEventListener("click",function(){
	home.classList.add("activado");
	// aplicar logica para que se oculten todas las secciones y solo se muestre la seccion de home
})